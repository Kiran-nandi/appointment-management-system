<?php echo $__env->make('doctors/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="page-content">
    <div class="container-fluid">
        <div class="row mt-5">
            <div class="form-group col-md-12">
                <h4>All Appointments List</h4>
                <br />
                <table class="table">
                    <thead>
                        <tr>
                            <th>Sr. no.</th>
                            <th>Name</th>
                            <th>Number</th>
                            <th>Email</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Status</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $srno = 1; ?>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($srno++); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->number); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td><?php echo e($data->date); ?></td>
                            <td><?php echo e($data->time); ?></td>
                            <td>
                                <select class="form-control Ustatus" data-id="<?php echo e($data->id); ?>" >
                                    <option disabled>Update Status</option>
                                    <option value="waiting for approval" <?php if($data->status == 'waiting for approval') {echo 'selected';} ?>>Waiting for Approval</option>
                                    <option value="Approve" <?php if($data->status == 'Approve') {echo 'selected';} ?>>Approve</option>
                                    <option value="Discard" <?php if($data->status == 'Discard') {echo 'selected';} ?>>Discard</option>
                                    <option value="Fulfilled" <?php if($data->status == 'Fulfilled') {echo 'selected';} ?>>Fulfilled</option>
                                </select>
                            </td>
                            <td><a href="delete-doctor-appointment/<?php echo e($data->id); ?>" style="color: red;font-size: 20px;text-align: center;"><i class="fa fa-trash"></i></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $('.Ustatus').change(function() {
        var status = $(this).find(":selected").val();
        var id = $(this).attr('data-id');
        console.log(id);
        console.log(status);
        $.ajax({
            url: '<?php echo e(route("upadatestatus")); ?>',
            type: 'post',
            dataType: 'json',
            data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                status: status,
                id: id
            },
            success: function(result) {
                if(result == 'success') {
                    window.location.reload();
                } else {
                    alert('something went wrong!! please try again');
                }
            },
            error: function(err) {
                console.log('Error >>', err);
            }
        });
    })
</script>
<?php echo $__env->make('doctors/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\appointment-management\resources\views/doctors/doctorappointmentlist.blade.php ENDPATH**/ ?>